#!/bin/bash
# GSL test kit setup. Needs network (Settings: allow network for the code tool).
set -e
npm config set prefix /home/claude/.npm-global
export PATH=/home/claude/.npm-global/bin:$PATH
npm install -g typescript@5 playwright@1 react@18.3.1 react-dom@18.3.1 tailwindcss@3.4.17 postcss@8
npx playwright install chromium
mkdir -p /home/claude/gsl
cp -r test /home/claude/gsl/
ln -sfn /home/claude/.npm-global/lib/node_modules/react /home/claude/gsl/test/node_modules/react
ln -sfn /home/claude/.npm-global/lib/node_modules/react-dom /home/claude/gsl/test/node_modules/react-dom
mkdir -p /home/claude/gsl/src /home/claude/gsl/design /home/claude/gsl/backups
cp design/helpers.py /home/claude/gsl/design/
echo "Now copy the project files (flat) into /home/claude/gsl/src, then: cd /home/claude/gsl/test && node syntax.js && node build.js && node render.js snap"
