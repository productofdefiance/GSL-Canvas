# GSL test kit (from Canvas v51.15)

The harness Claude used to check every build: syntax, a full server render of every page and tab,
a real browser (Playwright + Chromium) for interactions, light / dark, desktop / phone.

## Setup (new chat, once)

1. Unzip this kit in the container: `cd /home/claude && unzip gsl-test-kit.zip -d gsl-test-kit`.
2. Network must be on (Anish: Settings, allow network for the code tool). Run `cd gsl-test-kit && ./setup.sh`.
   It installs TypeScript, Playwright + Chromium, React 18.3.1, Tailwind 3.4.17 and PostCSS globally,
   copies the kit to `/home/claude/gsl/test`, and links React into the test folder.
3. Copy Anish's project files into `/home/claude/gsl/src/` **flat** (App.js, ui.js, League.js, LeagueTabs.js,
   Cups.js, CupsLab.js, Pyramid.js, Squad.js, index.js, index.html, sheetData.js). No folders.

## Every build

```
cd /home/claude/gsl/test
node syntax.js                 # parse every file
node build.js                  # transpile src/*.js to out/ (useState values can be forced via globalThis.__OV)
node render.js snapN           # render every page x tab at 390 and 1440: errors, sub-11px text, 5a snapshot
node css.js snapN cssC.css     # Tailwind CSS for the browser, prefixed with index.html's <style>
cd browser && node bundle.js entry.js app.bundle.js
node shots6.js '[{"w":1440,"ov":{"App:sectionId":"league","League:activeTab":"spider"},"out":"x.png","dark":true}]'
node ow.js                     # phone overflow check on every League tab (scrollWidth must equal 390)
```

## Forcing state

`build.js` rewrites `const [x, setX] = useState(init)` to read `globalThis.__OV['<FileStem>:x']` first,
so a test can open any tab or view: `{"App:sectionId":"league","League:activeTab":"race","LeagueTabs:mode":"compare"}`.
Tab ids: league overview, fixtures, clubs, race, analytics, homeaway, spider.

## Example interaction tests (browser/)

- `touch_t.js`: simulated finger drag on the Points race (PointerEvent with pointerType 'touch'); checks the docked card.
- `sp_t.js`: Spider Matrix: picker, typing focus, swap, quick picks, Group add / remove, table, dark, phone.
- `rv.js`: a review-fix pass: header alignment by measured positions, two-column list, hover cards, ledger switch.
- `capsec.js`: captures each section of a tab as HTML for design inventories.

Habits: scope clicks to `main` (tab names repeat in the header); scroll an element into view before
screenshots; measure positions with `getBoundingClientRect` rather than judging from a cropped image.

## Design mocks (design/helpers.py)

Python helpers for mock HTML (section, option frames, records, segmented controls). Mocks are rendered,
compiled with css.js-style Tailwind, screenshotted, then published to a Claude Design file as `.dc.html`
boards (`<script src="./support.js">`, stylesheet uploaded as an asset, board listed in `project/canvas.json`).
Read `canvas.json` right before publishing it.

## Blind spots

- The server render has no CSS: it can't judge layout, overflow or widths. Use the browser for those.
- The browser uses compiled Tailwind and the real fonts may not load (offline): pixel-perfect type checks
  belong to Anish's screens.
- Canvas design files can show stale pages to Anish after a publish; check the published file first.
